/* Include files */

#include "aries_cgxe.h"
#include "m_GsWAdTuVq4OTcGrkaBng1B.h"
#include "m_thVImgD4pFFBEFdOY55S2C.h"
#include "m_PxwJbTodL6JbK1FcQUKP1.h"

unsigned int cgxe_aries_method_dispatcher(SimStruct* S, int_T method, void* data)
{
  if (ssGetChecksum0(S) == 754021842 &&
      ssGetChecksum1(S) == 3918455155 &&
      ssGetChecksum2(S) == 3710732318 &&
      ssGetChecksum3(S) == 1873977561) {
    method_dispatcher_GsWAdTuVq4OTcGrkaBng1B(S, method, data);
    return 1;
  }

  if (ssGetChecksum0(S) == 1783509398 &&
      ssGetChecksum1(S) == 1005817221 &&
      ssGetChecksum2(S) == 4046966856 &&
      ssGetChecksum3(S) == 3821677367) {
    method_dispatcher_thVImgD4pFFBEFdOY55S2C(S, method, data);
    return 1;
  }

  if (ssGetChecksum0(S) == 2905321144 &&
      ssGetChecksum1(S) == 399732648 &&
      ssGetChecksum2(S) == 2631079035 &&
      ssGetChecksum3(S) == 1521227278) {
    method_dispatcher_PxwJbTodL6JbK1FcQUKP1(S, method, data);
    return 1;
  }

  return 0;
}
